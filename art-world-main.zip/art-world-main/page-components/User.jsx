import UserPosts from "./UserPosts";

export default function User({ user }) {
  return <UserPosts user={user} />;
}
