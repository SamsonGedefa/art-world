import { atom } from "recoil";

export const updatePostState = atom({
  key: "updatePostState",
  default: false,
});

// export const getPostState = atom({
//   key: "getPostState",
//   default: {},
// });
