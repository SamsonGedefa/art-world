import { atom } from "recoil";

export const navMenuState = atom({
  key: "navMenuState",
  default: false,
});
